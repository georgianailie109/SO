#include <stdio.h>
#include <internal/syscall.h>
#include <errno.h>
#include <unistd.h>

int puts(const char *str) {
    int i = 0;
    while (str[i] != '\0') {
        write(1, str + i, 1);
        i++;
    }
    write(1, "\0\n", 2);
    return i + 1;
}
