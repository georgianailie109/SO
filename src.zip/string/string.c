// SPDX-License-Identifier: BSD-3-Clause

#include <string.h>

char *strcpy(char *destination, const char *source)
{
	/* TODO: Implement strcpy(). */
	int i = 0;
	while (source[i] != '\0') {
		destination[i] = source[i];
		i++;
	}
	destination[i] = '\0';
	return destination;
}

char *strncpy(char *destination, const char *source, size_t len)
{
	/* TODO: Implement strncpy(). */
	int i = 0;
	while (source[i] != '\0' && len > 0) {
		destination[i] = source[i];
		i++;
		len--;
	}
	if (len > 0) {
		destination[i] = '\0';
	}
	return destination;
}

char *strcat(char *destination, const char *source)
{
	/* TODO: Implement strcat(). */
	int i = 0, j = 0;
	while (destination[i] != '\0') {
		i++;
	}
	while (source[j] != '\0') {
		destination[i] = source[j];
		i++;
		j++;
	}
	destination[i] = '\0';
	return destination;
}

char *strncat(char *destination, const char *source, size_t len)
{
	/* TODO: Implement strncat(). */
	int i = 0, j = 0;
	while (destination[i] != '\0') {
		i++;
	}
	while (source[j] != '\0' && len > 0) {
		destination[i] = source[j];
		i++;
		j++;
		len--;
	}
	destination[i] = '\0';
	return destination;
}

int strcmp(const char *str1, const char *str2)
{
	/* TODO: Implement strcmp(). */
	int i = 0;
	while (str1[i] == str2[i] && str1[i] != '\0') {
		i++;
	}
	if (str1[i] == '\0' && str2[i] == '\0') {
		return 0;
	} else if (str1[i] != '\0' && str2[i] == '\0') {
		return 1;
	} else if (str1[i] == '\0' && str2[i] != '\0') {
		return -1;
	} else if (str1[i] != '\0' && str2[i] != '\0') {
		if (str1[i] > str2[i]) {
			return 1;
		}
		return -1;
	}
	return 0;
}

int strncmp(const char *str1, const char *str2, size_t len)
{
	/* TODO: Implement strncmp(). */
	int i = 0;
	while ((str1[i] == str2[i] && str1[i] != '\0') && len > 0) {
		i++;
		len--;
	}
	if ((str1[i] == '\0' && str2[i] == '\0') || len == 0) {
		return 0;
	} else if (str1[i] != '\0' && str2[i] == '\0') {
		return 1;
	} else if (str1[i] == '\0' && str2[i] != '\0') {
		return -1;
	} else if (str1[i] != '\0' && str2[i] != '\0') {
		if (str1[i] > str2[i]) {
			return 1;
		}
		return -1;
	}
	return 0;
}

size_t strlen(const char *str)
{
	size_t i = 0;

	for (; *str != '\0'; str++, i++)
		;

	return i;
}

char *strchr(const char *str, int c)
{
	/* TODO: Implement strchr(). */
	for (; *str != '\0' && *str != c; str++)
		;
	if (*str == c) {
		return (char *)str;
	}
	return NULL;
}

char *strrchr(const char *str, int c)
{
	/* TODO: Implement strrchr(). */
	const char *rez = NULL;
	while (*str != '\0') {
		if (*str == c) {
			rez = str;
		}
		str++;
	}
	return (char *)rez;
}

char *strstr(const char *haystack, const char *needle)
{
	/* TODO: Implement strstr(). */
	const char *s, *p, *q;
	for (s = haystack; *s; s++) {
		p = s;
		q = needle;
		while (*q) {
			if (*p != *q) {
				break;
			}
			p++;
			q++;
		}
		if (*q == '\0') {
			return (char *)s;
		}
	}
	return NULL;
}

char *strrstr(const char *haystack, const char *needle)
{
	/* TODO: Implement strrstr(). */
	const char *s, *p, *q;
	for (s = haystack + strlen(haystack) - 1; s >= haystack; s--) {
		p = s;
		q = needle + strlen(needle) - 1;
		while (*p == *q) {
			if (q == needle) {
				return (char *)s - strlen(needle) + 1;
			}
			p--;
			q--;
		}
	}
	return NULL;
}

void *memcpy(void *destination, const void *source, size_t num)
{
	/* TODO: Implement memcpy(). */
	char *dest = (char *)destination;
	const char *src = (const char *)source;
	int i;
	for (i = 0; i < (int)num; i++) {
		dest[i] = src[i];
	}
	return destination;
}

void *memmove(void *destination, const void *source, size_t num)
{
	/* TODO: Implement memmove(). */
	char *dest = destination;
	const char *src = source;
	int i = 0;
	while (src[i] != '\0' && num > 0) {
		dest[i] = src[i];
		i++;
		num--;
	}
	if (num > 0) {
		dest[i] = '\0';
	}
	return destination;
}

int memcmp(const void *ptr1, const void *ptr2, size_t num)
{
	/* TODO: Implement memcmp(). */
	const char *p1 = (const char *)ptr1;
	const char *p2 = (const char *)ptr2;
	int i = 0;
	while ((p1[i] == p2[i] && p1[i] != '\0') && num > 0) {
		i++;
		num--;
	}
	if ((p1[i] == '\0' && p2[i] == '\0') || num == 0) {
		return 0;
	} else if (p1[i] != '\0' && p2[i] == '\0') {
		return 1;
	} else if (p1[i] == '\0' && p2[i] != '\0') {
		return -1;
	} else if (p1[i] != '\0' && p2[i] != '\0') {
		if (p1[i] > p2[i]) {
			return 1;
		}
		return -1;
	}
	return 0;
}

void *memset(void *source, int value, size_t num)
{
	/* TODO: Implement memset(). */
	char *src = (char *)source;
	int i;
	for (i = 0; i < (int)num; i++) {
		src[i] = value;
	}
	return source;
}
