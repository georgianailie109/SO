#include <time.h>
#include <internal/syscall.h>
#include <errno.h>
#include <unistd.h>

unsigned int sleep(unsigned int seconds)
{
    struct timespec t;
    t.tv_sec = seconds;
    t.tv_nsec = 0;
    if (nanosleep(&t, &t) != 0) {
        return t.tv_sec;
    }
    return 0;
}
