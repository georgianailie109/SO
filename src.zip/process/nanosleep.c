#include <time.h>
#include <internal/syscall.h>
#include <errno.h>
#include <unistd.h>

int nanosleep(const struct timespec *req, struct timespec *rem)
{
    struct timespec temp;
    int ret = syscall(__NR_nanosleep, req, &temp);
    if (ret < 0) {
        if (rem != NULL) {
            rem->tv_sec = temp.tv_sec;
            rem->tv_nsec = temp.tv_nsec;
        }
        return -1;
    }
    return 0;
}
